/*
 * @Author: ch cwl_ch@163.com
 * @Date: 2022-12-19 10:58:26
 * @LastEditors: ch
 * @LastEditTime: 2023-01-03 15:21:49
 * @Description: file content
 */
const STORAGE_KEY = {
    token : 'tk',
    userInfo : 'u_i',
    serverConf: 's_c'
}
export default STORAGE_KEY;