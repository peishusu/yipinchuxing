<script setup>

import { onLaunch } from "@dcloudio/uni-app";

onLaunch(()=> {
})
</script>

<style>
/*每个页面公共css */
</style>
